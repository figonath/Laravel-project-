<?php
    error_reporting(1);
    @session_start();
    if($_SESSION["logstatus"] === "Active")
    {

    	
    require_once("../db_connect/config.php");
    require_once("../db_connect/conect.php");

    $db = new database();
    
    
$User_Name=$_SESSION["name"];
$date=date("d-m-Y");


    if(isset($_GET['print']))
    {
        $src_text=$_GET['print'];
        $query="SELECT * FROM `mamber` WHERE `id`='$src_text'";
        $chek=$db->select_query($query);
        if($chek)
            {
                $fetch=$chek->fetch_array();



                
            }
    }


 if(isset($_GET['print']))
    {
        $src_textt=$_GET['print'];
        $querya="SELECT * FROM `depo_with` WHERE `mamber_id`='$src_textt'";
        $cheka=$db->select_query($querya);
        if($cheka)
            {
                $fetcha=$cheka->fetch_array();



                
            }
    }

 if(isset($_GET['print']))
    {
        $src_text=$_GET['print'];
        $qurya="SELECT * FROM `deposit_money` WHERE `mamber_id`='$src_text'";
        $chka=$db->select_query($qurya);
        if($chka)
            {
                $ftcha=$chka->fetch_array();



                
            }
    }



 $projectinfo="SELECT  * FROM `project_info`";
    $result=$db->select_query($projectinfo);
    if($result>0){
      $fetch_result=$result->fetch_array();
    }
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <title>Admin Panal || <?php if(isset($fetch_result)){ echo $fetch_result["title"];} else {echo "";}?></title>
  
  <?php 
   require_once("includ/form_hader.php");
  ?>

</head>

<body>

<!-- Main content -->
            <div class="invoice p-3 mb-3">
              <!-- title row -->
              <div class="row">
                <div class="col-12">
                  <h4>
                    <i class="fas fa-book"></i> &nbsp;<?php if(isset($fetch_result)){ echo $fetch_result["title"];} else {echo "";}?>

                    <small class="float-right">Date : <?php echo date("d/m/Y");?>  / Mamber Report.</small><hr>
                  </h4>
                </div>
                <!-- /.col -->
              </div>
              <!-- info row -->
              <div class="row invoice-info">
                <div class="col-sm-4 invoice-col">
                  <address>
                    <strong><?php echo $fetch[1];?>.</strong>
                    <br><?php if(isset($fetch_result)){ echo $fetch_result["address"];} else {echo "";}?>
                    <br>
                    Phone: (+88) <?php echo $fetch[3];?><br>
                    Email: <?php echo $fetch[4];?>
                  </address>
                </div>
                <!-- /.col -->
                <div class="col-sm-4 invoice-col">
                  
                </div>
                <!-- /.col -->
                <div class="col-sm-4 invoice-col">
                  <b>Invoice #<?php echo $fetcha[0];?></b><br>
                  <br>
                  <b>Mamber ID :</b> <?php echo $fetch[0];?><br>
                  <b>Account Open Date :</b> <?php echo $fetch[9];?><br>
                  <b>Account ID:</b> 000-<?php echo $ftcha[0];?>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <!-- Table row -->
              <div class="row">
                <div class="col-6 table-responsive">
                  <table class="table table-striped">
                    <thead>
                    <tr>
                      <th>Serial #</th>
                      <th>Date & Time</th>
                      <th>Deposit</th>
                    </tr>
                    </thead>
                    <tbody>
                   
                   <?php
                   if ($_GET['print']){
                   		$sl=1;
                   
	           	        $src_text=$_GET['print'];
				        $qurwya="SELECT * FROM `deposit_money` WHERE `mamber_id`='$src_text'";
				        $chkwa=$db->select_query($qurwya);
				        if($chkwa>0){

				            	while ($fetcwh=$chkwa->fetch_array()) {
				              
							
                   ?>
                    <tr>
                      <td><?php echo $sl;?></td>
                      <td><?php echo $fetcwh[1];?></td>
                      <td align="center"><?php echo $fetcwh[4];?> </td>
                    </tr>

                    <?php $sl++; }}}?>
                    <tfoot>
                    	<tr>
                    		<td colspan="2"><b>Total :</b></td>
                    		<td colspan="1" align="center">
                    			<?php 
                    	if ($_GET['print']) {
                    		
                    	
                    		$src_text=$_GET['print'];
			                   $quer="SELECT SUM(`amount`) FROM `deposit_money` WHERE `mamber_id`='$src_text'";
			                        $che=$db->select_query($quer);
			                            if ($fet=$che->fetch_array()) {
			                              $with=$fet[0];
			                              if ($with!=0) {
			                              	echo$with;
			                              }else{
			                              	echo '0.00';
			                              }

                        }
                    else{
                        	 echo'0.00';
                        }}	
                        ?><i>Tk.</i>
                    		</td>
                    	</tr>
                    </tfoot>

                    </tbody>
                  </table>
                  
                </div>

                <div class="col-6 table-responsive">
                  <table class="table table-striped">
                    <thead>
                    <tr>
                      <th>Serial #</th>
                      <th>Date & Time</th>
                      <th>Withdraw</th>
                    </tr>
                    </thead>
                    <tbody>
                   
                   <?php
                   if ($_GET['print']){
                   		$sl=1;
                   
	           	        $src_text=$_GET['print'];
				        $qurwya="SELECT * FROM `withdraw` WHERE `mamber_id`='$src_text'";
				        $chkwa=$db->select_query($qurwya);
				        if($chkwa>0){

				            	while ($fetcwh=$chkwa->fetch_array()) {
				              
							
                   ?>
                    <tr>
                      <td><?php echo $sl;?></td>
                      <td><?php echo $fetcwh[1];?></td>
                      <td align="center"><?php echo $fetcwh[4];?></td>
                    </tr>

                    <?php $sl++; }}}?>
                    <tfoot>
                    	<tr>

                    		<td colspan="2"><b>Total :</b></td>
                    		<td colspan="1" align="center">
                    	<?php 
                    	if ($_GET['print']) {
                    		
                    	
                    		$src_text=$_GET['print'];
			                   $quer="SELECT SUM(`amount`) FROM `withdraw` WHERE `mamber_id`='$src_text'";
			                        $che=$db->select_query($quer);
			                            if ($fet=$che->fetch_array()) {
			                              $with=$fet[0];
			                              
			                              if ($with!=0) {
			                              	echo$with;
			                              }else{
			                              	echo '0.00';
			                              }


                        }
                        }	
                        ?><i>Tk.</i>


                    		</td>

                    	</tr>
                    </tfoot>

                    </tbody>
                  </table>
                 
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->
<hr style="border: 1px solid #ddd;">
              <div class="row">
                <!-- accepted payments column -->
                <div class="col-6">
                  <p class="lead">Payment Methods :</p>
                  
                  <img src="dist/img/credit/bkash.png" style="border: 1px solid#82807b;
    width: 80px;
    padding: 2px;
    height: 40px;" alt="Paypal">
                   <img src="dist/img/credit/rocket.png" style="border: 1px solid#82807b;
    width: 80px;
    padding: 2px;
    height: 40px;" alt="Paypal">
                    <img src="dist/img/credit/nagod.png" style="border: 1px solid#82807b;
    width: 80px;
    padding: 2px;
    height: 40px;" alt="Paypal">

                  <p class="text-muted well well-sm shadow-none" style="margin-top: 10px;">
                  	We are Accpet Bkash, Rocket, Nagad.<br>
                    Our Bkash Number <b>01878218803</b>.
                    Rocket Number <b>01878218803-2</b>.
                  	<br>
                  	Thanks ..For Your Deposit.
                  </p>
                  

                  <span class="text-muted well well-sm shadow-none" style="margin-top: 10px;">Sign in ..................................................</span>
                  <br>
                  <span class="text-muted well well-sm shadow-none" style="margin-top: 10px;">Developed by Figo Nath. </span>
                </div>

                <div class="col-2"  id="SivaDiv" style="@media print { .graph-img img {display:inline;}}">
            
                  <img src="output-onlinepngtools.png" alt="Graph Description" style="margin-left: -150px; margin-top: -66px;" />
   
                </div>


                <!-- /.col -->
                <div class="col-4">
                  <p class="lead">Your Total Report : </p>

                  <div class="table-responsive">
                    <table class="table">
                    	<?php
                      	if ($_GET['print']) {
                    		
                    	
                    		$src_text=$_GET['print'];
			                   $ques="SELECT SUM(`amount`) FROM `deposit_money` WHERE `mamber_id`='$src_text'";
			                        $chese=$db->select_query($ques);
			                        $feset=$chese->fetch_array();
			                        $des=$feset[0];
			                            if ($des<=1040) {
			                              
                      ?>
                      <tr>
                        <th style="width:50%">Total Amount :</th>
                        <td>1040.00 <i>Tk</i></td>
                      </tr>
                      <?php }else{}}?>
                      <tr>
                        <th>Total Deposit :</th>
                        <td><?php 
                    	if ($_GET['print']) {
                    		
                    	
                    		$src_text=$_GET['print'];
			                   $quer="SELECT SUM(`amount`) FROM `deposit_money` WHERE `mamber_id`='$src_text'";
			                        $che=$db->select_query($quer);
			                            if ($fet=$che->fetch_array()) {
			                              $with=$fet[0];
			                              if ($with!=0) {
			                              	echo$with;
			                              }else{
			                              	echo '0.00';
			                              }

                        }}	
                        ?> <i>Tk</i></td>
                      </tr>
                      <tr>
                        <th>Total Withdraw :</th>
                        <td><?php 
                    	if ($_GET['print']) {
                    		
                    	
                    		$src_text=$_GET['print'];
			                   $quer="SELECT SUM(`amount`) FROM `withdraw` WHERE `mamber_id`='$src_text'";
			                        $che=$db->select_query($quer);
			                            if ($fet=$che->fetch_array()) {
			                              $with=$fet[0];
			                              
			                              if ($with!=0) {
			                              	echo$with;
			                              }else{
			                              	echo '0.00';
			                              }


                        }
                        }	
                        ?> <i>Tk</i></td>
                      </tr>
                      <tr>
                        <th>Your Total Balance :</th>
                        <td><?php 
                    	if ($_GET['print']) {
                    		
                    	
                    		$src_text=$_GET['print'];
			                   $queer="SELECT SUM(`amount`) FROM `deposit_money` WHERE `mamber_id`='$src_text'";
			                        $chee=$db->select_query($queer);
			                            if ($feet=$chee->fetch_array()) {
			                              $de=$feet[0];
			                              if ($de!=0) {
			                              	
			                              	$quer="SELECT SUM(`amount`) FROM `withdraw` WHERE `mamber_id`='$src_text'";
			                        		$che=$db->select_query($quer);
			                            		if ($fet=$che->fetch_array()) {
			                              		$with=$fet[0];

			                              		echo $de-$with;





			                              	}

			                              }else{
			                              	echo '0.00';
			                              }

                        }}	
                        ?> <i>Tk</i></td>
                      </tr>

                      <?php
                      	if ($_GET['print']) {
                    		
                    	
                    		$src_text=$_GET['print'];
			                   $ques="SELECT SUM(`amount`) FROM `deposit_money` WHERE `mamber_id`='$src_text'";
			                        $chese=$db->select_query($ques);
			                        $feset=$chese->fetch_array();
			                        $des=$feset[0];
			                            if ($des<=1040) {
			                              
                      ?>

                      <tr>
                      	<th>Total Due :</th>
                      	<td><?php 
                    	if ($_GET['print']) {
                    		  $src_text=$_GET['print'];
                            $qureys="SELECT SUM(`amount`) FROM `deposit_money` WHERE `mamber_id`='$src_text'";
                              $cheswe=$db->select_query($qureys);
                              $fesset=$cheswe->fetch_array();
                              $depo=$fesset[0];
                              if ($depo==0) {
                                $qwiths="SELECT SUM(`amount`) FROM `withdraw` WHERE `mamber_id`='$src_text'";
                              $cwitnswe=$db->select_query($qwiths);
                              $fwithet=$cwitnswe->fetch_array();
                              $withd=$fwithet[0];  
                              echo $withd+1040;echo".00";

                              } else {
                                
                                $ths="SELECT SUM(`amount`) FROM `withdraw` WHERE `mamber_id`='$src_text'";
                              $cswe=$db->select_query($ths);
                              $fwith=$cswe->fetch_array();
                              $witfd=$fwith[0];
                              $total=$depo-$witfd;

                             $ttt=1040-$total;

                              if ($ttt!=0) {
                                      echo$ttt;
                                    }else{
                                      echo '0.00';
                                    }

                              }
                              
                              
                              
                              

			                   


                        }?> <i>Tk</i></td>
                      </tr>

                  <?php }else{}}?>
                    </table>
                  </div>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <!-- this row will not appear when printing -->
              <div class="row no-print">
                <div class="col-12">
                  
                 <input type="submit" name="print" id="print" class="noneBtnForprin btn btn-info float-right" onClick="return window.print()" value="Print"/>
                </div>
              </div>
            </div>
            <!-- /.invoice -->

<?php 
   require_once("includ/form_hader_footer.php");
?>

<!-- <script type="text/javascript"> 
  window.addEventListener("load", window.print());
</script> -->

    <script type="text/javascript">
        function printPage(elementId) {
            var printContent = document.getElementById(elementId);
            var windowUrl = 'about:blank';
            var uniqueName = new Date();
            var windowName = 'Print' + uniqueName.getTime();
            var printWindow = window.open(windowUrl, windowName, 'left=50000,top=50000,width=0,height=0');

            printWindow.document.write(printContent.innerHTML);
            printWindow.document.close();
            printWindow.focus();
            printWindow.print();
            printWindow.close();
        }
    </script>

</body>
</html>
<?php } else { print "<script>location='../adminloginpanel/index.php'</script>";}?>
