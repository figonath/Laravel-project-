<?php
    error_reporting(1);
    @session_start();
    date_default_timezone_set("Asia/Dhaka");

    if($_SESSION["logstatus"] === "Active")
    {

    	
    require_once("../db_connect/config.php");
    require_once("../db_connect/conect.php");

    $db = new database();
    
    
$User_Name=$_SESSION["name"];
$date=date("d-m-Y");
$time=date("h:i a");


 $depo_with="SELECT  * FROM `depo_with`";
    $res=$db->select_query($depo_with);
    if($res>0){
      $fetch=$res->fetch_array();
    }

 $mamber="SELECT  * FROM `cost`";
    $ress=$db->select_query($mamber);
    if($ress>0){
      $fetchs=$ress->fetch_array();
    }


 $projectinfo="SELECT  * FROM `project_info`";
    $result=$db->select_query($projectinfo);
    if($result>0){
      $fetch_result=$result->fetch_array();
    }
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <title>Admin Panal || <?php if(isset($fetch_result)){ echo $fetch_result["title"];} else {echo "";}?></title>
  
  <?php 
   require_once("includ/form_hader.php");
  ?>

</head>

<body>

<!-- Main content -->
            <div class="invoice p-3 mb-3">
              <!-- title row -->
              <div class="row">
                <div class="col-12">
                  <h4>
                    <i class="fas fa-book"></i> &nbsp;<?php if(isset($fetch_result)){ echo $fetch_result["title"];} else {echo "";}?>

                    <small class="float-right">Date : <?php echo date("d/m/Y");?>  / Cost Report.</small><hr>
                  </h4>
                </div>
                <!-- /.col -->
              </div>
              <!-- info row -->
              <div class="row invoice-info">
                <div class="col-sm-4 invoice-col">
                  <address>
                    <strong><?php if(isset($fetch_result)){ echo $fetch_result["project_name"];} else {echo "";}?></strong>
                    <br><?php if(isset($fetch_result)){ echo $fetch_result["address"];} else {echo "";}?>
                    <br>
                    Phone : (+88) <?php if(isset($fetch_result)){ echo $fetch_result["phone_number"];} else {echo "";}?><br>
                    Email : <?php if(isset($fetch_result)){ echo $fetch_result["email"];} else {echo "";}?>
                  </address>
                </div>
                <!-- /.col -->
                <div class="col-sm-4 invoice-col">
                  
                </div>
                <!-- /.col -->
                <div class="col-sm-4 invoice-col">
                  <b>Invoice #<?php if(isset($fetchs)){ echo $fetchs["id"].'.';} else {echo "";} echo date("his");?></b><br>
                  <br>
                  <b>INDEX NO :</b> <?php 
                    $ques="SELECT COUNT(id) FROM `cost`";
                              $chese=$db->select_query($ques);
                              $feset=$chese->fetch_array();
                              echo date("dm")."-".$feset[0]."-".date("hi");
                  ?><br>
                  <b>Open Date : <?php if(isset($fetchs)){ echo $fetchs["date"].'.';} else {echo "";}?></b> <br>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <!-- Table row -->
              <div class="row">
                <div class="col-12 table-responsive">
                  <table class="table table-striped">
                    <thead>
                    <tr align="center">
                      <th style="width:10%">Serial #</th>
                      <th style="width:50%">Item Name</th>
                      <th style="width:20%">Quantity / kg</th>
                      <th style="width:20%">Amount</th>
                    </tr>
                    </thead>
                    <tbody>
                   
                  <?php
                    $sl=1;
                    $query="SELECT * FROM `bazar_list`";
                    $result=$db->select_query($query);
                    
                
                    if($result)
                    {
                        while ($fetcharry=$result->fetch_array()) {
                      
                          
                  ?>
                    <tr align="center" >

                      <td style="width:10%"><?php echo $sl;?></td>
                      <td style="width:50%" align="left"><?php echo $fetcharry[1];?></td>
                      <td style="width:20%"></td>
                      <td style="width:20%" align="center"></td>
                    </tr>

                    <?php $sl++; }}?>
                  

                    </tbody>
                  </table>
                  
                </div>

              </div>
              <!-- /.row -->
<hr style="border: 1px solid #ddd;">
              <div class="row">
                <!-- accepted payments column -->
                <div class="col-5">
                  <p class="lead">Contact Now :</p>
                  

                  <p class="text-muted well well-sm shadow-none" style="margin-top: 5px;">
                    Phone : (+88) <?php if(isset($fetch_result)){ echo $fetch_result["phone_number"];} else {echo "";}?><br>
                    Email : <?php if(isset($fetch_result)){ echo $fetch_result["email"];} else {echo "";}?>
                  
                  	
                  </p>
                  
                  <span class="text-muted well well-sm shadow-none" style="margin-top: 5px;">Developed by Figo Nath. </span>
                </div>

                <div class="col-2"  id="SivaDiv" style="@media print { .graph-img img {display:inline;}}">
            
                  <img src="output-onlinepngtools.png" alt="Graph Description" style="margin-left: -150px; margin-top: -66px;" />
   
                </div>

                <!-- /.col -->
                <div class="col-5">
                  <p class="lead">Our Report : </p>

                  <div class="table-responsive">
                    <table class="table">
                    	

                      <tr>
                        <th style="width:80%">Total Balance :</th>
                        <td style="width:20%" align="center"><b>
                          <?php
                          $quees="SELECT SUM(`amount`) FROM `deposit_money`";
                              $chesee=$db->select_query($quees);
                              $feseet=$chesee->fetch_array();
                              $dep=$feseet[0];

                          $qeeues="SELECT SUM(`amount`) FROM `withdraw`";
                              $cheeese=$db->select_query($qeeues);
                              $feseeet=$cheeese->fetch_array();
                              $with=$feseeet[0];

                              $total=$dep-$with;


                              $quess="SELECT SUM(`amount`) FROM `donation`";
                              $chesse=$db->select_query($quess);
                              $fesset=$chesse->fetch_array();
                              $tot=$total+$fesset[0];

                              $queqss="SELECT SUM(`amount`) FROM `previous_year`";
                              $chqesse=$db->select_query($queqss);
                              $fqesset=$chqesse->fetch_array();

                                $top=$tot+$fqesset[0];

                                $queeeer="SELECT SUM(`amount`) FROM `cost`";
                                $cheee=$db->select_query($queeeer);
                                $fetee=$cheee->fetch_array();
                                $witrh=$top-$fetee[0];
                                

                              if ($witrh==0) {
                                echo "0.00";
                              } else {
                                echo $witrh;echo'.00';
                              }
                              
                             
                          ?>
                         <i>Tk</i></b></td>
                      </tr>


                      
                     
                    </table>
                    <hr style="border: 1px solid #ddd;">
                  </div>
                </div>
                <!-- /.col -->
              </div>
              <!-- /.row -->

              <!-- this row will not appear when printing -->
              <div class="row no-print">
                <div class="col-12">
                  
                 <input type="submit" name="print" id="print" class="noneBtnForprin btn btn-info float-right" onClick="return window.print()" value="Scale 96 Print"/>
                </div>
              </div>
            </div>
            <!-- /.invoice -->

<?php 
   require_once("includ/form_hader_footer.php");
?>

<!-- <script type="text/javascript"> 
  window.addEventListener("load", window.print());
</script> -->

    <script type="text/javascript">
        function printPage(elementId) {
            var printContent = document.getElementById(elementId);
            var windowUrl = 'about:blank';
            var uniqueName = new Date();
            var windowName = 'Print' + uniqueName.getTime();
            var printWindow = window.open(windowUrl, windowName, 'left=50000,top=50000,width=0,height=0');

            printWindow.document.write(printContent.innerHTML);
            printWindow.document.close();
            printWindow.focus();
            printWindow.print();
            printWindow.close();
        }
    </script>
</body>
</html>
<?php } else { print "<script>location='../adminloginpanel/index.php'</script>";}?>
