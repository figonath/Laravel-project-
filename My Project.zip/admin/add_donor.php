<?php
    error_reporting(1);
    @session_start();
    if($_SESSION["logstatus"] === "Active")
    {
    require_once("../db_connect/config.php");
    require_once("../db_connect/conect.php");

    $db = new database();
      
$User_Name=$_SESSION["name"];
$date=date("d-m-Y");

$id=$db->autogenerat('donar','id','DONAR-','10');
$name=isset($_POST["name"])?$_POST["name"]:"";
$title=isset($_POST["title"])?$_POST["title"]:"";
$number=isset($_POST["number"])?$_POST["number"]:"";
$email=isset($_POST["email"])?$_POST["email"]:"";
$nid=isset($_POST["nid"])?$_POST["nid"]:"";
$fb=isset($_POST["fb"])?$_POST["fb"]:"";

if(isset($_POST["addbtn"]))
{
    if(!empty($name) && !empty($number))
    {

     
                $sql="INSERT INTO `donar`(`id`,`name`, `tital`, `number`, `email`, `nid`, `fb`, `img`, `user`, `add_date`) VALUES ('$id','$name','$title','$number','$email','$nid','$fb','$file_ext','$User_Name','$date')";

                $resultisnsert=$db->insert_query($sql);

               $Paht="all_image/donar/".$id.".jpg";
              move_uploaded_file($_FILES["file"]["tmp_name"],$Paht);
               
}

else{?>
      <script>alert('Sorry !! Text Field is Empty...')</script><?php
    }

}

//link edit data................................... 
$fetch[0]="";
$fetch[1]="";
$fetch[2]="";
$fetch[3]="";
$fetch[4]="";
$fetch[5]="";
$fetch[6]="";
    if(isset($_GET['edit']))
    {
        $src_text=$_GET['edit'];
        $query="SELECT * FROM `donar` WHERE `id`='$src_text'";
        $chek=$db->select_query($query);
        if($chek)
            {
                $fetch=$chek->fetch_array();


                
            }
    }

$ids=$fetch[0];

if(isset($_POST["editbtn"]))
{
   if(!empty($name) && !empty($number))
    {
      $sql="REPLACE INTO `donar`(`id`,`name`, `tital`, `number`, `email`, `nid`, `fb`, `img`, `user`, `add_date`) VALUES ('$ids','$name','$title','$number','$email','$nid','$fb','$file_ext','$User_Name','$date')";

        $resultupdate=$db->update_query($sql); 

        $Paht="all_image/donar/".$ids.".jpg";
        move_uploaded_file($_FILES["file"]["tmp_name"],$Paht);       
      }
        


    else{?>
      <script>alert('Sorry !! Text Field is Empty...')</script><?php
    }



}


//end link edit data.....
//link dlt data.....................................
//     if(isset($_GET['dlt']))
//     {
//         $linid=$db->escape($_GET['dlt']);
//         $query="DELETE FROM `Project_Info` WHERE `email`='$linid'";
//         $delete=$db->delete_query($query);
//         // $fetch[0]=$db->withoutPrefix('add_class','id',"31".$prefix,'12');
//         echo "alert('Confrom Delete...');<script>location='Project_Info.php'</script>";


//     }

 if (isset($_POST["refresh"])) 
    {
        echo "<script>location='add_donor.php'</script>";
    }

 if (isset($_POST["view"])) 
    {
        echo "<script>location='View_donor.php'</script>";
    }
    


 $projectinfo="SELECT  * FROM `project_info`";
    $result=$db->select_query($projectinfo);
    if($result>0){
      $fetch_result=$result->fetch_array();
    }
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <title>Admin Panal || <?php if(isset($fetch_result)){ echo $fetch_result["title"];} else {echo "";}?></title>
  
  <?php 
   require_once("includ/form_hader.php");
  ?>

</head>

<body>

<div class="wrapper">

     <section class="content">
      <div class="container">
        <div class="row">


<div class="col-md-12 " style="margin: auto; margin-top: 50px;">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Add A New Donar.</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
        <form method="post" enctype="multipart/form-data">
        <div class="card-body">
                  <div class="form-group">
                    <label>Name :</label> <span style="color: red;"><small><b>Requirement.</b></small></span>
                    <input type="text" class="form-control" name="name" value="<?php echo $fetch[1];?>"autocomplete="off" id="" placeholder="Enter New Mamber Name...">
                   
                  </div>
              
                  <div class="form-group">
                    <label>Title :</label> <span style="color: red;"><small><b>Not Requirement.</b></small></span>
                    <input type="text" class="form-control" name="title" value="<?php echo $fetch[2];?>"autocomplete="off" placeholder="Enter Title...">
                   
                  </div>

                <div class="form-group">
                    <label>Number :</label> <span style="color: red;"><small><b>Requirement.</b></small></span>
                    <input type="number" name="number" autocomplete="off" class="form-control" placeholder="018********" value='<?php echo $fetch[3];?>'>
                </div>


                <div class="form-group">
                    <label>Email :</label> <span style="color: red;"><small><b>Not Requirement.</b></small></span>
                    <input type="email" name="email" class="form-control" autocomplete="off" placeholder="demo@gmail.com" value='<?php echo $fetch[4];?>'>
                </div>


                  <div class="form-group">
                    <label>Nid / Birth Registration No :</label> <span style="color: red;"><small><b>Not Requirement.</b></small></span>
                    <input type="number" class="form-control" name="nid" value="<?php echo $fetch[5];?>"autocomplete="off" id="" placeholder="2589*****5214865">
                   
                  </div>

                  <div class="form-group">
                    <label>Facebook Id Link : </label> <span style="color: red;"><small><b>Not Requirement.</b></small></span>
                    <input type="text" name="fb" class="form-control" placeholder="https://www.facebook.com/figonath2013/" autocomplete="off" value='<?php echo $fetch[6];?>'>
                </div>

                <div class="form-group custom-file"> 
                      <input type="file" class="custom-file-input" name="file" id="customFile">
                      <label class="custom-file-label" for="customFile">Choose Image</label>
                      <br>
                      <span><img src="all_image/Male.jpg" id="profile-img-tag" width="70px" height="65px" /></span>
                        
                      <br>
                </div>
                <br><br>
                <span><h5 align="center"><?php echo $db->sms; ?><?php echo $mes; ?></h5> </span> 


        </div>
       <div class="card-footer bg-white">
            
            
            <?php
              if (isset($_GET['edit'])) {}else{
           ?>
                       
              <button  type="submit" title="ব্যবহার করুন" name="addbtn" class="btn btn-success pull-right"> Save </button>
        
           <?php }?>

            <button  type="submit" title="আপডেট করতে ব্যবহার করুন।" name="editbtn" class="btn btn-primary pull-right"> Edit </button>


            <button  type="submit" title="ডাটা সব দেখুন।" name="view" class="btn btn-info pull-right"> View </button>

            <button  type="submit" title="সব মুছে ফেলুন" name="refresh" class="btn btn-danger"> Refresh </button>


        </div>
        </form>
         </div>  
          </div>
            </div>


          </div>
          </section>
</div>



<?php 
   require_once("includ/form_hader_footer.php");
?>
</body>
</html>
<?php } else { print "<script>location='../adminloginpanel/index.php'</script>";}?>
