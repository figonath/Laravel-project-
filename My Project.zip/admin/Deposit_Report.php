
<?php
       date_default_timezone_set("Asia/Dhaka");
    error_reporting(1);
    @session_start();
    if($_SESSION["logstatus"] === "Active")
    {
    require_once("../db_connect/config.php");
    require_once("../db_connect/conect.php");

    $db = new database();
    $User_Type=$_SESSION["type"];   


    $User_Name=$_SESSION["name"];
    $date_time=date("d-m-Y")." / ".date("h:i a");
    $total=isset($_POST["total"])?$_POST["total"]:"";

    if(isset($_GET['edit']))
    {
        $mamber_id=$_GET['edit'];
        $query="SELECT * FROM `depo_with` WHERE `mamber_id`='$mamber_id'";
        $chek=$db->select_query($query);
        if($chek)
            {
                $fetch=$chek->fetch_array();

                $id=$fetch[0];
                $name=$fetch[1];

                $quer="SELECT SUM(`amount`) FROM `deposit_money` WHERE `mamber_id`='$mamber_id'";
                $reslt=$db->select_query($quer);

                if ($feth=$reslt->fetch_array()) {
                $deps=$feth[0];

                
                  $queree="SELECT SUM(`amount`) FROM `withdraw` WHERE `mamber_id`='$mamber_id'";
                  $reslte=$db->select_query($queree);
                    if ($feath=$reslte->fetch_array()) {
                      $withdraw=$feath[0];
                      $totall=$deps-$withdraw;

                $sql="REPLACE INTO `depo_with`(`id`, `name`, `mamber_id`, `depo`, `with`, `total`, `admin`, `date`) VALUES ('$id','$name','$mamber_id','$deps','$withdraw','$totall','$User_Name','$date_time')";
                $resultupdate=$db->update_query($sql);
                    }
                



                }
  
            }
    }




     $projectinfo="SELECT  * FROM `project_info`";
    $result=$db->select_query($projectinfo);
    if($result>0){
      $fetch_result=$result->fetch_array();
    }


?>
<!doctype html>
<html lang="en">

<!-- Mirrored from bootadmin.net/demo/datatables by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 30 Dec 2019 05:20:22 GMT -->
<!-- Added by HTTrack -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Admin Panal || <?php if(isset($fetch_result)){ echo $fetch_result["title"];} else {echo "";}?></title>
  <?php 
   require_once("includ/form_hader.php");
  ?>
</head>
<body class="bg-light">

   <div class="d-flex">
    

        <div class="content p-4">
                            <div class="text-center mb-4">
                    <script async src="../../pagead2.googlesyndication.com/pagead/js/f.txt"></script>
                    <!-- Responsive -->
                    <ins class="adsbygoogle"
                         style="display:block"
                         data-ad-client="ca-pub-4097235499795154"
                         data-ad-slot="5211442851"
                         data-ad-format="auto"></ins>
                    <script>
                    (adsbygoogle = window.adsbygoogle || []).push({});
                    </script>
                </div>
            
               <!--  <h2 class="mb-4">Datatables</h2>
 -->
    <div class="card mb-4">
        <div class="card-body">
            <table id="example" class="table table-hover"  cellspacing="0" width="100%">
                <thead>
                <tr>
                    <th>NAME</th>
                    <th>DEPOSIT TK</th>
                    <th>WITHDRAW TK</th>
                    <th>TOTAL TK</th>
                    <?php
                         $query="SELECT * FROM `admin_users` WHERE `type`!='Main Admin'";
                         $chek=$db->select_query($query);
                         $fetch=$chek->fetch_array();
                         if ($fetch[4]==$User_Type) {}else{
                    ?>
                    <th>ACTION</th> 
                    <?php }?>
                   
                </tr>
                </thead>
                <form method="post">
                <tbody>
                 <?php
                
                    $query="SELECT * FROM `mamber` ORDER BY `id` DESC ";
                    $result=$db->select_query($query);
                    
                
                    if($result)
                    {
                        while ($fetcharry=$result->fetch_array()) {

                          if ($fetcharry) {
                            $quer="SELECT SUM(`amount`) FROM `deposit_money` WHERE `mamber_id`='$fetcharry[0]'";
                            $reslt=$db->select_query($quer);
                                
                              if($reslt)
                                {
                                  while ($fetch=$reslt->fetch_array()) {
                                    if ($fetch) {

                                      $queree="SELECT SUM(`amount`) FROM `withdraw` WHERE `mamber_id`='$fetcharry[0]'";

                                        $reslte=$db->select_query($queree);
                                            
                                          if($reslte)
                                            {
                                              while ($fetceh=$reslte->fetch_array()) {
                                   
                                    
                                    
                                  
                          
                  ?>
                <tr>
                   
                   
                    <td><input type="text" class="form-control" name="name" value="<?php echo $fetcharry[1];?>" readonly></td>
                    <td><input type="number" class="form-control" name="dep" value="<?php if($fetch[0]>0){ echo $fetch[0];}else{echo'0';}?>" readonly></td>
                    <td><input type="number" class="form-control" name="with" value="<?php if($fetceh[0]>0){echo $fetceh[0];}else{echo '0';}?>" readonly></td>
                    <td><input type="number" class="form-control" name="total" value="<?php echo $fetch[0]-$fetceh[0];?>" readonly></td>

                    <?php
                         $query="SELECT * FROM `admin_users` WHERE `type`!='Main Admin'";
                         $chek=$db->select_query($query);
                         $fetch=$chek->fetch_array();
                         if ($fetch[4]==$User_Type) {}else{
                    ?>
                    <td>
                      
                      <?php 
                        $quey="SELECT * FROM `depo_with` WHERE `mamber_id`='$fetcharry[0]'";
                         $che=$db->select_query($quey);
                         $fetc=$che->fetch_array();
                         if ($fetc[5]!='0') {?>
                            

                            <a href="Deposit_Report.php?edit=<?php echo $fetcharry[0];?>" class="btn btn-icon btn-pill btn-success" data-toggle="tooltip" title="Save"><i class="fa fa-fw fa-save"></i></a>
                        <?php }else{?>
                          <a href="Deposit_Report.php?edit=<?php echo $fetcharry[0];?>" class="btn btn-icon btn-pill btn-danger" data-toggle="tooltip" title="Save"><i class="fa fa-fw fa-save"></i></a>
                     <?php }?>

                      

                      
                        
                        <a href="mamber_by_report.php?print=<?php echo $fetcharry[0];?>" class="btn btn-icon btn-pill btn-info" target="_blank" data-toggle="tooltip" title="Print"><i class="fa fa-fw fa-print"></i></a>
                    </td>
                   <?php }?>
                </tr>             
              <?php }}}}}}}}?>


<tfoot>
                 
                  <td></td>
                  <td></td>
                  <td></td>
                 

                  <td style="text-align: center;"><h6>TOTAL BALANCE = <?php 

                        $query="SELECT SUM(`amount`) FROM `deposit_money`";
                        $chek=$db->select_query($query);
                         
                        if ($fetc=$chek->fetch_array()) {
                          $dep=$fetc[0];
                        $quer="SELECT SUM(`amount`) FROM `withdraw`";
                        $che=$db->select_query($quer);
                            if ($fet=$che->fetch_array()) {
                              $with=$fet[0];
                              echo$dep-$with;

                        }}?><i> TK.</i></h6></td>
                  <?php
                         $query="SELECT * FROM `admin_users` WHERE `type`!='Main Admin'";
                         $chek=$db->select_query($query);
                         $fetch=$chek->fetch_array();
                         if ($fetch[4]==$User_Type) {}else{
                    ?>
                  
                  <td></td>
                  <?php }?>
                  
                </tr>
              </tfoot>

                </tbody>
                </form>
            </table>
        </div>
    </div>
    </div>
    </div>
<span><h5 align="center"><?php echo $db->sms; ?></h5> </span> 
<?php 
   require_once("includ/form_hader_footer.php");
?>

</body>

<!-- Mirrored from bootadmin.net/demo/datatables by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 30 Dec 2019 05:20:22 GMT -->
</html>
<?php } else { print "<script>location='../adminloginpanel/index.php'</script>";}?>