<?php  include('../counter.php');?>


<?php
    @error_reporting(1);
    @session_start();

    date_default_timezone_set("Asia/Dhaka");

    if($_SESSION["logstatus"] === "Active")
    {
    require_once("../db_connect/config.php");
    require_once("../db_connect/conect.php");

    $db = new database();


$User_Name=$_SESSION["name"];

$message=isset($_POST["message"])?$_POST["message"]:"";

$date=date("d-m-Y");

$time=date("h:i a");



$id=$db->autogenerat('bazar_list','id','BAZAR-','10');

$item=isset($_POST["item"])?$_POST["item"]:"";

$price=isset($_POST["price"])?$_POST["price"]:"";





if(isset($_POST["a_ddbtn"]))
{
    if(!empty($item) && !empty($price))
    {

     $sql="INSERT INTO `bazar_list`(`id`, `item`, `price`, `valu`) VALUES ('$id','$item','$price','Inactive')";

                $resultisnsert=$db->insert_query($sql);
               
}

else{?>
      <script>alert('Sorry !! Text Field is Empty...')</script><?php
    }

}


//link edit data................................... 
$fetch[0]="";
$fetch[1]="";
$fetch[2]="";
$fetch[3]="";

if(isset($_GET['edit']))
    {
        $src_text=$_GET['edit'];
        $query="SELECT * FROM `bazar_list` WHERE `id`='$src_text'";
        $chek=$db->select_query($query);
        if($chek)
            {
                $fetch=$chek->fetch_array();

                $sql="REPLACE INTO `bazar_list`(`id`, `item`, `price`, `valu`) VALUES ('$fetch[0]','$fetch[1]','$fetch[2]','Active')";

               
               if ($sql) {
                $resultupdate=$db->update_query($sql);
                  echo "<script>location='index.php'</script>";
               }

            }
    }






 $hits=("Select * From `total_login` where `name`='$User_Name' && `date`='$date' limit 1 ");

 $chek=$db->select_query($hits);
        if($chek)
            {
                $fetch=$chek->fetch_array();
                
            }
$n= $fetch[4]+1;

        
if (isset( $fetch)) {

  $query=("Update `total_login` Set `hits`= '$n' where `name`='$fetch[1]'");
  $resultupdate=$db->update_query($query);

} else {
  

        

          $query=("INSERT INTO `total_login`(`name`,`time`,`date`,`hits`) VALUES ('$User_Name','$time','$date','1')"); 
           $resultisnsert=$db->insert_query($query);       
}






if(isset($_POST["send"]))
{

    if(!empty($message))
    {
        $sql="INSERT INTO `message`(`name`, `date`, `time`, `message`) VALUES ('$User_Name','$date','$time','$message')";

        $resultisnsert=$db->insert_query($sql);       
   
}
else{echo "<script>alert('Sorry !! Teyp Your Message...');</script>";}
}


?>
        <!-- Small boxes (Stat box) -->
        <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h3> <?php
                
                    $select_total="SELECT COUNT(`id`) FROM `mamber`";
                    $fetchTotal=$db->select_query($select_total);
                    
                    if($fetchTotal)
                    {


                            $fetchData=$fetchTotal->fetch_array();
                          print $fetchData[0];
                    
                    }
                    

                    ?></h3>

                <p>TOTAL MEMBERS</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="View_mamber.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3> <?php
                
                    $select_total="SELECT COUNT(`id`) FROM `admin_users`";
                    $fetchTotal=$db->select_query($select_total);
                    
                    if($fetchTotal)
                    {


                          $fetchData=$fetchTotal->fetch_array();
                          print $fetchData[0];
                    
                    }
                    

                    ?><sup style="font-size: 20px"></sup></h3>

                <p>Total Admin</p>
              
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars">
                  
                <?php

                ?>
                </i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3><?php
                $qureys="SELECT SUM(`amount`) FROM `deposit_money`";
                              $cheswe=$db->select_query($qureys);
                              $fesset=$cheswe->fetch_array();
                              $depo=$fesset[0];
                    
                    if($depo)
                    {


                           
                            print$depo;
                    
                    }else
                    {
                        print '0.00 ';
                    }
                    

                    ?></h3>

                <p>TOTAL DEPOSIT</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="Deposit_Money_view.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h3><?php
                $qureys="SELECT SUM(`amount`) FROM `withdraw`";
                              $cheswe=$db->select_query($qureys);
                              $fesset=$cheswe->fetch_array();
                              $depo=$fesset[0];
                    
                    if($depo)
                    {


                           
                            print$depo;
                    
                    }else
                    {
                        print '0.00 ';
                    }
                    

                    ?></h3>

                <p>TOTAL WITHDRAW</p>
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
              <a href="Withdraw_Money_view.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
        </div>
        <!-- /.row -->


        <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
                <h3> <?php
                
                    $select_total="SELECT SUM(`amount`) FROM `donation`";
                    $fetchTotal=$db->select_query($select_total);
                    
                    if($fetchTotal)
                    {


                            $fetchData=$fetchTotal->fetch_array();

                            if ($fetchData[0]==0) {
                              print "0.00";
                            } else {
                              print $fetchData[0];
                            }
                            
                          
                    
                    }
                    

                    ?></h3>

                <p>TOTAL DONATION</p>
              </div>
              <div class="icon">
                <i class="ion ion-bag"></i>
              </div>
              <a href="donation_view.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3><?php
                
                    $select_total="SELECT SUM(`amount`) FROM `cost`";
                    $fetchTotal=$db->select_query($select_total);
                    
                    if($fetchTotal)
                    {


                            $fetchData=$fetchTotal->fetch_array();

                            if ($fetchData[0]==0) {
                              print "0.00";
                            } else {
                              print $fetchData[0];
                            }
                            
                          
                    
                    }
                    

                    ?></h3>

                <p>TOTAL COST</p>
              
              </div>
              <div class="icon">
                <i class="ion ion-stats-bars">
                </i>
              </div>
              <a href="view_cost" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3><?php
                $qureys="SELECT SUM(`amount`) FROM `previous_year`";
                              $cheswe=$db->select_query($qureys);
                              $fesset=$cheswe->fetch_array();
                              $depo=$fesset[0];
                    
                    if($depo)
                    {


                           
                            print$depo;
                    
                    }else
                    {
                        print '0.00 ';
                    }
                    

                    ?></h3>

                <p>PREVIOUS BALANCE</p>
              </div>
              <div class="icon">
                <i class="ion ion-person-add"></i>
              </div>
              <a href="previous_money_add.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h3><?php
                          $quees="SELECT SUM(`amount`) FROM `deposit_money`";
                              $chesee=$db->select_query($quees);
                              $feseet=$chesee->fetch_array();
                              $dep=$feseet[0];

                          $qeeues="SELECT SUM(`amount`) FROM `withdraw`";
                              $cheeese=$db->select_query($qeeues);
                              $feseeet=$cheeese->fetch_array();
                              $with=$feseeet[0];

                              $total=$dep-$with;


                              $quess="SELECT SUM(`amount`) FROM `donation`";
                              $chesse=$db->select_query($quess);
                              $fesset=$chesse->fetch_array();
                              $tot=$total+$fesset[0];

                              $queqss="SELECT SUM(`amount`) FROM `previous_year`";
                              $chqesse=$db->select_query($queqss);
                              $fqesset=$chqesse->fetch_array();

                                $top=$tot+$fqesset[0];

                                $queeeer="SELECT SUM(`amount`) FROM `cost`";
                                $cheee=$db->select_query($queeeer);
                                $fetee=$cheee->fetch_array();
                                $witrh=$top-$fetee[0];
                                

                              if ($witrh==0) {
                                echo "0.00";
                              } else {
                                echo $witrh;echo'.00';
                              }
                              
                             
                          ?></h3>

                <p>TOTAL BALANCE</p>
                
              </div>
              <div class="icon">
                <i class="ion ion-pie-graph"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
        </div>



        <div class="card direct-chat direct-chat-primary">
              <div class="card-header">
                <h3 class="card-title">Chat & Comment.</h3>

                <div class="card-tools">
                  
                  <button type="button" class="btn btn-tool" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  
                    <a href="index.php"class="btn btn-tool"><img src="all_image/loading.gif" style="height: 20px; width: 20px;"></a>
                  
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                <!-- Conversations are loaded here -->
                <div class="direct-chat-messages">
                  <!-- Message. Default to the left -->



                  <?php


                 
                    $quersy="SELECT * FROM `mamber` WHERE `id`='$message' || `name`='$message'";
                    $resuslt=$db->select_query($quersy);
                    if ($resuslt) {
                   
                    $fetcee=$resuslt->fetch_array();

                    if ($message==$fetcee[0] || $fetcee[1]) {?>


                     <div class="direct-chat-msg left">
                    

                  
          
                    <!-- /.direct-chat-img -->
                    <div class="direct-text" style="background-color: #ddd;">
                      <p class="lead">Name : <?php echo$fetcee[1] ; ?></p>
                  

                  <p class="text-muted well well-sm shadow-none" style="margin-top: 1px;">
                    Deposit Total : <?php
                         $quer="SELECT SUM(`amount`) FROM `deposit_money` WHERE `mamber_id`='$fetcee[0]'";
                              $che=$db->select_query($quer);
                                  if ($fet=$che->fetch_array()) {
                                    $with=$fet[0];
                                    if ($with!=0) {
                                      echo$with;
                                    }else{
                                      echo '0.00';
                                    }

                        }

                    ?> <i>Tk</i><br>

                    Withdraw Total : <?php
                         $quer="SELECT SUM(`amount`) FROM `withdraw` WHERE `mamber_id`='$fetcee[0]'";
                              $che=$db->select_query($quer);
                                  if ($fet=$che->fetch_array()) {
                                    $with=$fet[0];
                                    
                                    if ($with!=0) {
                                      echo$with;
                                    }else{
                                      echo '0.00';
                                    }


                        }

                    ?> <i>Tk</i><br>

                    Your Total Balance : <?php
                         $quer="SELECT SUM(`amount`) FROM `deposit_money` WHERE `mamber_id`='$fetcee[0]'";
                              $che=$db->select_query($quer);
                                  if ($fet=$che->fetch_array()) {
                                    $with=$fet[0];
                                    if ($with!=0) {
                                      echo$with;
                                    }else{
                                      echo '0.00';
                                    }

                        }
                    else{
                           echo'0.00';
                        }

                    ?> <i>Tk</i><br>
                  
                    
                  </p>
                    </div>
                    <!-- /.direct-chat-text -->
                  </div>














                      
                   <?php } }else{
                    

                   

                    $query="SELECT * FROM `message`";
                    $result=$db->select_query($query);
                    
                
                    if($result)
                    {
                        while ($fetcharry=$result->fetch_array()) {
                          if ($fetcharry[1] == $User_Name) {
                            
                          
                          
                  ?>

                                     <!-- Message to the right -->
                  <div class="direct-chat-msg right">
                    <div class="direct-chat-infos clearfix">
                      <span class="direct-chat-name float-right"><?php echo $fetcharry[1];?></span>
                      <span class="direct-chat-timestamp float-left"><?php echo $fetcharry[3];?>&nbsp;/&nbsp;<?php if ($fetcharry[2] == $date) {
                            echo"Today";
                          } else {
                            
                           echo $fetcharry[2];
                          
                        }?></span>
                    </div>
                    <!-- /.direct-chat-infos -->
                    <?php
                

                              if (file_exists('all_image/'.$pathdocument)) 
                                {

                  ?>

                  <img class="direct-chat-img" src="all_image/<?php echo $_SESSION["id"];?>.jpg" alt="message user image">

              <?php  } 
                else {?>
                  <img class="direct-chat-img" src="all_image/male.jpg" alt="Not Use Image.">
                <?php }?>
          
                    <!-- /.direct-chat-img -->
                    <div class="direct-chat-text">
                      <?php echo $fetcharry[4];?>
                    </div>
                    <!-- /.direct-chat-text -->
                  </div>
                  <!-- /.direct-chat-msg -->




                  <?php } else { ?>
                    

                  <div class="direct-chat-msg">
                    <div class="direct-chat-infos clearfix">
                      <span class="direct-chat-name float-left"><?php echo $fetcharry[1];?></span>
                      <span class="direct-chat-timestamp float-right"><?php echo $fetcharry[3];?>&nbsp;/&nbsp;
                        <?php if ($fetcharry[2] == $date) {
                            echo"Today";
                          } else {
                            
                           echo $fetcharry[2];
                          
                        }?>
                        </span>
                    </div>
                    <!-- /.direct-chat-infos -->
                <?php

                    if (file_exists('all_image/'.$pathdocument)) 
                       {

                          $src_text=$fetcharry[1];
                          $query="SELECT * FROM `admin_users` WHERE `Name`='$src_text'";
                          $chek=$db->select_query($query);
                          if($chek)
                              {
                                  $fetch=$chek->fetch_array(); 
                              } 
                ?>

                  <img class="direct-chat-img" src="all_image/<?php echo $fetch[0];?>.jpg" alt="message user image">

              <?php  } else {?>
                
                  <img class="direct-chat-img" src="all_image/male.jpg" alt="He Not Use Img.">
              <?php }?>
          

                    
                    <!-- /.direct-chat-img -->
                    <div class="direct-chat-text">
                      <?php echo $fetcharry[4];?>
                    </div>
                    <!-- /.direct-chat-text -->
                  </div>

                  <?php }}} }?>

                 






                </div>

                <!-- /.direct-chat-pane -->
              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                <form action="#" method="post">
                  <div class="input-group">
                    <input type="text" autocomplete="off" name="message" placeholder="Type Message / Type Your Mamber ID / NAME ..." class="form-control">
                    <span class="input-group-append">
                      <button type="submit" name="send" class="btn btn-primary">Send</button>
                    </span>
                  </div>
                </form>
              </div>
              <!-- /.card-footer-->
            </div>


    

        <div class="row">
          <!-- Left col -->
          <section class="col-lg-7 connectedSortable">
            <div class="col-md-12">
            <div class="card">
              <div class="card-header p-2">
                <ul class="nav nav-pills">
                  <li class="nav-item"><a class="nav-link active" href="#activity" data-toggle="tab">View</a></li>
                  <li class="nav-item"><a class="nav-link" href="#settings" data-toggle="tab">Add</a></li>
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
                <div class="tab-content">
                  <div class="tab-pane active" id="activity">
                    
              <div class="card-body table-responsive p-0">
                <table class="table table-striped table-valign-middle">
                  <thead>
                  <tr>
                    <th>Sl</th>
                    <th>Item Name</th>
                    <th>Approximately Price</th>
                    <th>Purchase</th>
                  </tr>
                  </thead>
                  <tbody>

                  <?php
                    $sl=1;
                    $query="SELECT * FROM `bazar_list`";
                    $result=$db->select_query($query);
                    
                
                    if($result)
                    {
                        while ($fetcharry=$result->fetch_array()) {
                  ?>

                  <tr>
                    <td><?php echo $sl; ?></td>
                    <td><?php echo $fetcharry[1]; ?></td>
                    <td><?php echo $fetcharry[2]; ?></td>
                    
                    <td>

                      <?php if($fetcharry["valu"]==="Active"){?>
                        <a href="#" class="btn btn-success btn-sm">Yes</a>
                      <?php } else {?>
                        <a href="dashboard.php?edit=<?php echo $fetcharry[0];?>" class="btn btn-danger btn-sm">No</a>
                      <?php } ?>

                    </td>

                    
                  </tr>
                  <?php $sl++;}} ?>
                  
                  </tbody>
                </table>
              </div>



                  </div>
                  <!-- /.tab-pane -->
                  

            <div class="tab-pane" id="settings">
              <div class="card-header bg-gradient-primary">
                <h3 class="card-title" style="text-align: center;">Add A New Item.</h3>
              </div>
               <form method="post" enctype="multipart/form-data">
                 <div class="card-body">


                  <div class="form-group">
                    
                    <input type="text" class="form-control" name="item" value="" autocomplete="off" id="" placeholder="Enter New Item Name...">
                   
                  </div>
              
                  <div class="form-group">
                    
                    <input type="text" class="form-control" name="price" value="" autocomplete="off" placeholder="Enter Approximately Price...">
                   
                  </div>

                 </div>
                   <div class="card-footer bg-white">
                        <button  type="submit" title="ব্যবহার করুন" name="a_ddbtn" class="btn btn-success pull-right"> Save </button>
                        </div>
                    </form>
            </div>
                  <!-- /.tab-pane -->
                </div>
                <!-- /.tab-content -->
              </div><!-- /.card-body -->
            </div>
            <!-- /.nav-tabs-custom -->
          </div>

          
          </section>


          <!-- right col (We are only adding the ID to make the widgets sortable)-->
          <section class="col-lg-5 connectedSortable">



            <!-- Calendar -->
            <div class="card bg-gradient-success">
              <div class="card-header border-0">

                <h3 class="card-title">
                  <i class="far fa-calendar-alt"></i>
                  Calendar
                </h3>
                <!-- tools card -->
                <div class="card-tools">
                  <!-- button with a dropdown -->
                  
                  <button type="button" class="btn btn-success btn-sm" data-card-widget="collapse">
                    <i class="fas fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-success btn-sm" data-card-widget="remove">
                    <i class="fas fa-times"></i>
                  </button>
                </div>
                <!-- /. tools -->
              </div>
              <!-- /.card-header -->
              <div class="card-body pt-0">
                <!--The calendar -->
                <div id="calendar" style="width: 100%"></div>
              </div>
              <!-- /.card-body -->
            </div>

            <!-- Map card -->
            <div class="card bg-gradient-primary">
              
             
              <!-- /.card-body-->
              <div class="card-footer bg-transparent">
                <div class="row">
                  <div class="col-4 text-center">
                    <div id="sparkline-1"></div>
                  </div>
                  <!-- ./col -->
                  <div class="col-4 text-center">
                    <div id="sparkline-2"></div>
                  </div>
                  <!-- ./col -->
                  <div class="col-4 text-center">
                    <div id="sparkline-3"></div>
                  </div>
                  <!-- ./col -->
                </div>
                <!-- /.row -->
              </div>
            </div>
            <!-- /.card -->

            
            <!-- /.card -->
          </section>
          <!-- right col -->
        </div>
        <!-- /.row (main row) -->
  <?php } else { print "<script>location='../adminloginpanel/index.php'</script>";}?>