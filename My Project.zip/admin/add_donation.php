<?php
    error_reporting(1);
    @session_start();

    date_default_timezone_set("Asia/Dhaka");
    if($_SESSION["logstatus"] === "Active")
    {
    require_once("../db_connect/config.php");
    require_once("../db_connect/conect.php");

    $db = new database();
$User_Type=$_SESSION["type"]; 
$User_Name=$_SESSION["name"];
$date=date("d-m-Y");

$time=date("h:i a");




$id=$db->autogenerat('donation','id','DONA-','10');
$date_time=date("d-m-Y")." / ".date("h:i a");
$name_mamber=isset($_POST["name_mamber"])?$_POST["name_mamber"]:"";
$mamber_id=isset($_POST["mamber_id"])?$_POST["mamber_id"]:"";
$amount=isset($_POST["amount"])?$_POST["amount"]:"";
// $total=isset($_POST["total"])?$_POST["total"]:"";



if(isset($_POST["addbtn"]))
{
    if(!empty($name_mamber) && !empty($amount) && !empty($mamber_id))
    {
      

                $sql="INSERT INTO `donation`(`id`, `date_time`, `donar_name`, `donar_id`, `amount`, `user_name`) VALUES ('$id','$date_time','$name_mamber','$mamber_id','$amount','$User_Name')";

                $resultisnsert=$db->insert_query($sql);
               
}

else{?>
      <script>alert('Sorry !! Text Field is Empty...')</script><?php
    }

}



//link edit data................................... 
$fetch[0]="";
$fetch[1]="";
$fetch[2]="";
$fetch[3]="";
$fetch[4]="";
$fetch[5]="";
$fetch[6]="";
    if(isset($_GET['edit']))
    {
        $src_text=$_GET['edit'];
        $query="SELECT * FROM `donation` WHERE `id`='$src_text'";
        $chek=$db->select_query($query);
        if($chek)
            {
                $fetch=$chek->fetch_array();


                
            }
    }

$ids=$fetch[0];

if(isset($_POST["editbtn"]))
{
   if(!empty($name_mamber) && !empty($amount))
    {
      $sql="REPLACE INTO `donation`(`id`, `date_time`, `donar_name`, `donar_id`, `amount`, `user_name`) VALUES ('$ids','$date_time','$name_mamber','$mamber_id','$amount','$User_Name')";

        $resultupdate=$db->update_query($sql); 
      
      }
        


    else{?>
      <script>alert('Sorry !! Text Field is Empty...')</script><?php
    }



}


 if (isset($_POST["refresh"])) 
    {
        echo "<script>location='add_donation.php'</script>";
    }

 if (isset($_POST["view"])) 
    {
        echo "<script>location='donation_view.php'</script>";
    }
    


 $projectinfo="SELECT  * FROM `project_info`";
    $result=$db->select_query($projectinfo);
    if($result>0){
      $fetch_result=$result->fetch_array();
    }
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <title>Admin Panal || <?php if(isset($fetch_result)){ echo $fetch_result["title"];} else {echo "";}?></title>
  
  <?php 
   require_once("includ/form_hader.php");
  ?>
  <script type="text/javascript">


    $(document).ready(function()
        {
                 $('#mamber_name').change(function()
                    {
                            searchmamber();
                    });

         
        });




    function searchmamber()
    {
        $('#mamber_id').html('');

        var loadingimg='<img src="loading.gif">';
        $('#loadingimage').html(loadingimg);

        var mamber_name=$('#mamber_name').val();
       // alert(itemName);
             $.post("search_donar.php",{mamber_name},
                    function(result)
                    { 
                        //alert(result);
                        $('#loadingimage').html('');
                          $('#mamber_id').html(result);

                    }


            );
    }


</script>
<script src="js/jquery-1.11.3.min.js" type="text/javascript"></script>
<script src="js/jquery-3.3.1.min.js" type="text/javascript"></script>

</head>

<body>

<div class="wrapper">

     <section class="content">
      <div class="container">
        <div class="row">


<div class="col-md-12 " style="margin: auto; margin-top: 50px;">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Donation Add.</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
        <form method="post" enctype="multipart/form-data">
        <div class="card-body">

                  <div class="form-group">
                    <label>Date & Time :</label>
                    <input type="text" readonly class="form-control" value="<?php if(isset($_GET['edit'])){print $fetch[1];}else{echo date("d-m-Y")." / ".date("h:i a");}?>"autocomplete="off" id="" placeholder="">
                   
                  </div>


                  <div class="form-group">
                    <label>Donar Name :</label> <span style="color: red;"><small><b>***</b></small></span>
                    
                    <select id="mamber_name" name="name_mamber" onchange="searchmamber()" class="form-control">
                      <option selected><?php if (isset($_GET['edit'])) {
                        print $fetch[2];
                      } else {
                        print"-Select Donar Name-";
                      }?>
                      </option>
                <?php
                
                    $query="SELECT * FROM `donar`";
                    $result=$db->select_query($query);
                    
                
                    if($result)
                    {
                        while ($fetcharry=$result->fetch_array()) {
                  ?>
                      <option><?php echo $fetcharry[1];?></option>
                  <?php }} ?>
                    </select>


                   
                  </div>

                  <div class="form-group">
                    <label>Donar ID :</label><label> <span id="loadingimage"></span></label>
                    <select  readonly name="mamber_id" id="mamber_id" class="form-control">
                      
                      <option selected><?php if (isset($_GET['edit'])) {
                        print $fetch[3];
                      } else {
                        print"Auto Complete..";
                      }?>
                      </option>
                      
                    </select>

                    
                   
                  </div>
              
                  <div class="form-group">
                    <label>Amount :</label> <span style="color: red;"><small><b>***</b></small></span>
                    <input type="text" class="form-control" id="Oprice" name="amount" value="<?php echo $fetch[4];?>"autocomplete="off" placeholder="Enter Amount...">
                   
                  </div>

                <!-- <div class="form-group">
                    <label>Total Paid :</label> <span style="color: red;"><small><b>***</b></small></span>
                    <input type="number" readonly name="total" id="result" class="form-control" placeholder="Auto Complete.." value='<?php ?>'>
                </div> -->


                <br>
                <span><h5 align="center"><?php echo $db->sms; ?></h5> </span> 


        </div>
       <div class="card-footer bg-white">
           <?php
              if (isset($_GET['edit'])) {}else{
           ?>
                       
              <button  type="submit" title="ব্যবহার করুন" name="addbtn" class="btn btn-success pull-right"> Save </button>
        
           <?php }?>
            <?php
                         $query="SELECT * FROM `admin_users` WHERE `type`!='Main Admin'";
                         $chek=$db->select_query($query);
                         $fetch=$chek->fetch_array();
                         if ($fetch[4]==$User_Type) {}else{
            ?>
            <button  type="submit" title="আপডেট করতে ব্যবহার করুন।" name="editbtn" class="btn btn-primary pull-right"> Edit </button>

            <?php }?>

            <button  type="submit" title="ডাটা সব দেখুন।" name="view" class="btn btn-info pull-right"> View </button>

            <button  type="submit" title="সব মুছে ফেলুন" name="refresh" class="btn btn-danger"> Refresh </button>


        </div>
        </form>
         </div>  
          </div>
            </div>


          </div>
          </section>
</div>



<?php 
   require_once("includ/form_hader_footer.php");
?>

<script>
    $('#Oprice').keyup(function(){
    var Oprice;
    Oprice = parseFloat($('#Oprice').val());
    var result = Oprice + 0;
    $('#result').val(result.toFixed(2));
    });
</script>

</body>
</html>
<?php } else { print "<script>location='../adminloginpanel/index.php'</script>";}?>
